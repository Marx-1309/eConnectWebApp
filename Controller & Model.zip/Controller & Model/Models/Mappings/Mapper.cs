﻿using AutoMapper;
using eConnectWebApp.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eConnectWebApp.Models.Mappings
{
    public class Mapper : Profile
    {
        public Mapper()
        {
            CreateMap<EmployeeListDetailsVm, Pay_Employee>().ReverseMap();
        }
    }
}